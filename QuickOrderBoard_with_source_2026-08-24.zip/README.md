# 快速委託面板

可建立不限列數的股票清單。每列只需輸入：

- 股票代號
- 張數（1 張 = 1,000 股）

程式啟動時會先顯示登入畫面，輸入身分證字號／帳號、登入密碼、憑證檔案與憑證密碼後才進入委託面板。登入資料只用於當次連線，不會儲存到設定檔。

登入畫面預設會記住帳號、登入密碼、憑證路徑及憑證密碼；資料會用 Windows DPAPI 加密，只能由同一台電腦的同一個 Windows 使用者帳戶讀取。取消勾選「記住登入資料」後登入，會清除已保存的登入資料。

委託面板可分別設定買入與賣出價格規則：

- 買入：委賣一 + N 檔、漲停價、跌停價或市價
- 賣出：委買一 - N 檔、跌停價、漲停價或市價

N 檔會依台股跳動單位逐檔計算；若超出券商提供的漲跌停範圍，會限制於該範圍內。

登入後，每列後方都有「買入」與「賣出」按鍵。按「買入」會讀取當下委賣一並以此價格送出整張限價買單；按「賣出」會讀取當下委買一並以此價格送出整張限價賣單。按鍵沒有第二次確認視窗。

## 執行

```powershell
cd D:\工作資料\Py\fubon_neo_test_web
python .\direct_order_board_gui\direct_order_board_gui.py
```

若直接雙擊 `.py` 沒有出現視窗，請改雙擊 `啟動快速委託面板.vbs`；它會固定使用已安裝富邦 Neo SDK 的 Python 3.12。

登入資訊讀取專案根目錄的 `ICE.env`（或 `.env`），沿用既有的 `test1`、`test2`、`prod` 設定檔。設定會自動儲存在本資料夾的 `direct_order_board_state.json`，下次開啟會還原；列數沒有程式限制。

## 測試

```powershell
python -m py_compile .\direct_order_board_gui\direct_order_board_gui.py
python -m unittest .\direct_order_board_gui\test_direct_order_board_gui.py
```
