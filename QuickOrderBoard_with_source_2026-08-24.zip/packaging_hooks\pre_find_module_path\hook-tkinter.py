"""Allow packaging tkinter when the host Python's Tcl discovery is broken.

The executable supplies Tcl/Tk data explicitly, so the normal availability
probe must not remove tkinter from PyInstaller's module search path.
"""


def pre_find_module_path(hook_api):
    del hook_api
