from __future__ import annotations

"""A compact multi-symbol stock order board for Fubon Neo.

The app starts with a credential entry screen. Each saved row represents one
stock code; its Buy and Sell buttons submit the configured board-lot limit
order immediately without a second confirmation dialog.
"""

import json
import os
import re
import sys
import ctypes
from ctypes import wintypes
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
TCL_RUNTIME_DIR = BASE_DIR / "runtime_tcl"
if not getattr(sys, "frozen", False) and (TCL_RUNTIME_DIR / "tcl8.6").is_dir() and (TCL_RUNTIME_DIR / "tk8.6").is_dir():
    os.environ["TCL_LIBRARY"] = str(TCL_RUNTIME_DIR / "tcl8.6")
    os.environ["TK_LIBRARY"] = str(TCL_RUNTIME_DIR / "tk8.6")

import threading
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk

from fubon_neo.constant import BSAction, MarketType, OrderType, PriceType, TimeInForce
from fubon_neo.sdk import FubonSDK, Mode, Order


STATE_PATH = BASE_DIR / "direct_order_board_state.json"
LOGIN_PROFILE_PATH = BASE_DIR / "direct_order_board_login.bin"
TAIPEI_TZ = timezone(timedelta(hours=8))
SYMBOL_PATTERN = re.compile(r"^[A-Z0-9]{2,10}$")
TEST_URL = "wss://neoapitest.fbs.com.tw/TASP/XCPXWS"


@dataclass(frozen=True)
class OrderRow:
    symbol: str = ""
    name: str = ""
    lots: str = "1"
    buy_mode: str = "ask_n"
    buy_ticks: str = "0"
    sell_mode: str = "bid_n"
    sell_ticks: str = "0"


@dataclass(frozen=True)
class LoginInput:
    user_id: str
    password: str
    cert_path: str
    cert_password: str
    environment: str


@dataclass(frozen=True)
class PriceSettings:
    buy_mode: str = "ask_n"
    buy_ticks: str = "0"
    sell_mode: str = "bid_n"
    sell_ticks: str = "0"


BUY_PRICE_MODES = {
    "ask_n": "委賣一 + N 檔",
    "limit_up": "漲停價",
    "limit_down": "跌停價",
    "market": "市價",
}
SELL_PRICE_MODES = {
    "bid_n": "委買一 - N 檔",
    "limit_down": "跌停價",
    "limit_up": "漲停價",
    "market": "市價",
}


class DataBlob(ctypes.Structure):
    _fields_ = (("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte)))


def _dpapi(data: bytes, protect: bool) -> bytes:
    """Encrypt/decrypt data for only the current Windows user account."""
    if os.name != "nt":
        raise RuntimeError("儲存登入資料僅支援 Windows。")
    buffer = ctypes.create_string_buffer(data)
    source = DataBlob(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_byte)))
    result = DataBlob()
    crypt32 = ctypes.windll.crypt32
    kernel32 = ctypes.windll.kernel32
    function = crypt32.CryptProtectData if protect else crypt32.CryptUnprotectData
    function.argtypes = (ctypes.POINTER(DataBlob), wintypes.LPCWSTR, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(DataBlob))
    function.restype = wintypes.BOOL
    if not function(ctypes.byref(source), None, None, None, None, 0x1, ctypes.byref(result)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(result.pbData, result.cbData)
    finally:
        kernel32.LocalFree(result.pbData)


def load_login_profile(path: Path = LOGIN_PROFILE_PATH) -> LoginInput | None:
    if not path.exists():
        return None
    try:
        raw = _dpapi(path.read_bytes(), protect=False)
        data = json.loads(raw.decode("utf-8"))
        return LoginInput(
            user_id=str(data["user_id"]), password=str(data["password"]),
            cert_path=str(data["cert_path"]), cert_password=str(data["cert_password"]),
            environment=str(data.get("environment", "prod")),
        )
    except (OSError, ValueError, KeyError, json.JSONDecodeError):
        return None


def save_login_profile(login: LoginInput, path: Path = LOGIN_PROFILE_PATH) -> None:
    path.write_bytes(_dpapi(json.dumps(asdict(login), ensure_ascii=False).encode("utf-8"), protect=True))


def clear_login_profile(path: Path = LOGIN_PROFILE_PATH) -> None:
    if path.exists():
        path.unlink()


def validate_login_input(login: LoginInput) -> None:
    labels = {
        "身分證字號／帳號": login.user_id,
        "登入密碼": login.password,
        "憑證檔案": login.cert_path,
        "憑證密碼": login.cert_password,
    }
    missing = [label for label, value in labels.items() if not value.strip()]
    if missing:
        raise ValueError(f"請輸入：{'、'.join(missing)}。")
    if not Path(login.cert_path).is_file():
        raise ValueError("找不到憑證檔案，請重新選擇。")


def make_login_sdk(login: LoginInput) -> FubonSDK:
    return FubonSDK(30, 2, url=TEST_URL) if login.environment == "test" else FubonSDK(30, 2)


def object_field(value: Any, *names: str) -> Any:
    for name in names:
        candidate = value.get(name) if isinstance(value, dict) else getattr(value, name, None)
        if candidate not in (None, ""):
            return candidate
    return None


def stock_accounts(login_result: Any) -> list[Any]:
    return [
        account
        for account in list(object_field(login_result, "data") or [])
        if str(object_field(account, "account_type", "accountType") or "stock").lower() != "futopt"
    ]


def account_label(account: Any) -> str:
    branch = object_field(account, "branch_no", "branchNo") or "--"
    number = object_field(account, "account") or "--"
    return f"{branch} / {number}"


def parse_symbol(value: str) -> str:
    symbol = value.strip().upper()
    if not SYMBOL_PATTERN.fullmatch(symbol):
        raise ValueError("股票代號必須為 2–10 碼英數字，例如 2330 或 00631L。")
    return symbol


def parse_lots(value: str) -> int:
    try:
        lots = int(value.strip())
    except (AttributeError, ValueError) as exc:
        raise ValueError("張數必須是正整數。") from exc
    if lots <= 0:
        raise ValueError("張數必須大於 0。")
    return lots * 1000


def positive_price(value: Any) -> str | None:
    try:
        price = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        return None
    if price <= 0:
        return None
    return format(price.normalize(), "f")


def decimal_price(value: Any) -> Decimal | None:
    text = positive_price(value)
    return Decimal(text) if text is not None else None


def parse_tick_count(value: str) -> int:
    try:
        count = int(value.strip())
    except (AttributeError, ValueError) as exc:
        raise ValueError("N 檔必須是 0 或正整數。") from exc
    if count < 0:
        raise ValueError("N 檔不能小於 0。")
    return count


def tick_for_price(price: Decimal, security_type: str = "") -> Decimal:
    if "ETF" in security_type.upper() or "ETN" in security_type.upper():
        return Decimal("0.01")
    if price < Decimal("10"):
        return Decimal("0.01")
    if price < Decimal("50"):
        return Decimal("0.05")
    if price < Decimal("100"):
        return Decimal("0.1")
    if price < Decimal("500"):
        return Decimal("0.5")
    if price < Decimal("1000"):
        return Decimal("1")
    return Decimal("5")


def move_ticks(price: Decimal, direction: int, count: int, security_type: str = "") -> Decimal:
    result = price
    for _ in range(count):
        if direction > 0:
            result += tick_for_price(result, security_type)
        else:
            just_below = result - Decimal("0.00000001")
            result -= tick_for_price(just_below, security_type)
    return result


def broker_price_bounds(response: Any) -> tuple[Decimal | None, Decimal | None]:
    data = object_field(response, "data") or response
    return (
        decimal_price(object_field(data, "limit_down_price", "limitDownPrice")),
        decimal_price(object_field(data, "limit_up_price", "limitUpPrice")),
    )


def selected_order_price(
    side: str, settings: PriceSettings, quote_snapshot: Any, broker_quote: Any,
) -> tuple[Any, str | None, str]:
    """Return (price_type, limit_price, human-readable rule) for an order."""
    mode = settings.buy_mode if side == "buy" else settings.sell_mode
    mode_labels = BUY_PRICE_MODES if side == "buy" else SELL_PRICE_MODES
    if mode == "market":
        return PriceType.Market, None, mode_labels[mode]
    lower, upper = broker_price_bounds(broker_quote)
    if mode == "limit_up":
        if upper is None:
            raise ValueError("券商未提供漲停價，未送出委託。")
        return PriceType.Limit, format(upper.normalize(), "f"), mode_labels[mode]
    if mode == "limit_down":
        if lower is None:
            raise ValueError("券商未提供跌停價，未送出委託。")
        return PriceType.Limit, format(lower.normalize(), "f"), mode_labels[mode]
    quote_side = "ask" if side == "buy" else "bid"
    reference = decimal_price(best_quote_price(quote_snapshot, quote_side))
    if reference is None:
        raise ValueError(f"目前沒有可用的{'委賣一' if side == 'buy' else '委買一'}價格，未送出委託。")
    count = parse_tick_count(settings.buy_ticks if side == "buy" else settings.sell_ticks)
    data = object_field(quote_snapshot, "data") or quote_snapshot
    security_type = str(object_field(data, "securityType", "security_type", "type") or "")
    price = move_ticks(reference, 1 if side == "buy" else -1, count, security_type)
    if lower is not None:
        price = max(price, lower)
    if upper is not None:
        price = min(price, upper)
    return PriceType.Limit, format(price.normalize(), "f"), f"{mode_labels[mode]}（{count} 檔）"


def best_quote_price(response: Any, side: str) -> str | None:
    """Return bid one or ask one from common Neo REST quote response shapes."""
    data = object_field(response, "data") or response
    book_keys = ("asks", "ask") if side == "ask" else ("bids", "bid")
    for key in book_keys:
        levels = object_field(data, key)
        if levels in (None, ""):
            continue
        if not isinstance(levels, (list, tuple)):
            levels = [levels]
        for level in levels:
            if isinstance(level, (list, tuple)):
                value = level[0] if level else None
            elif isinstance(level, (str, int, float, Decimal)):
                value = level
            else:
                value = object_field(level, "price", "p")
            price = positive_price(value)
            if price is not None:
                return price
    last_trade = object_field(data, "lastTrade", "last_trade")
    return positive_price(object_field(last_trade, side))


def stock_name(response: Any) -> str:
    """Extract a stock name from the common Neo REST quote response shapes."""
    data = object_field(response, "data") or response
    candidates = (data, object_field(data, "info", "stock", "security"))
    for candidate in candidates:
        for key in ("name", "shortName", "short_name", "companyName", "company_name"):
            value = object_field(candidate, key)
            if value not in (None, ""):
                return str(value)
    return "--"


def load_rows(path: Path = STATE_PATH) -> list[OrderRow]:
    if not path.exists():
        return []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        raw_rows = payload.get("rows", []) if isinstance(payload, dict) else []
        rows = [
            OrderRow(
                symbol=str(item.get("symbol", "")),
                name=str(item.get("name", "")),
                lots=str(item.get("lots", "1")),
                buy_mode=str(item.get("buy_mode", "ask_n")),
                buy_ticks=str(item.get("buy_ticks", "0")),
                sell_mode=str(item.get("sell_mode", "bid_n")),
                sell_ticks=str(item.get("sell_ticks", "0")),
            )
            for item in raw_rows
            if isinstance(item, dict) and str(item.get("symbol", "")).strip()
        ]
        return [
            OrderRow(
                symbol=row.symbol, name=row.name, lots=row.lots,
                buy_mode=row.buy_mode if row.buy_mode in BUY_PRICE_MODES else "ask_n",
                buy_ticks=row.buy_ticks, sell_mode=row.sell_mode if row.sell_mode in SELL_PRICE_MODES else "bid_n",
                sell_ticks=row.sell_ticks,
            )
            for row in rows
        ]
    except (OSError, json.JSONDecodeError):
        return []


def load_price_settings(path: Path = STATE_PATH) -> PriceSettings:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        raw = payload.get("price_settings", {}) if isinstance(payload, dict) else {}
        settings = PriceSettings(
            buy_mode=str(raw.get("buy_mode", "ask_n")), buy_ticks=str(raw.get("buy_ticks", "0")),
            sell_mode=str(raw.get("sell_mode", "bid_n")), sell_ticks=str(raw.get("sell_ticks", "0")),
        )
        return PriceSettings(
            buy_mode=settings.buy_mode if settings.buy_mode in BUY_PRICE_MODES else "ask_n",
            buy_ticks=settings.buy_ticks, sell_mode=settings.sell_mode if settings.sell_mode in SELL_PRICE_MODES else "bid_n",
            sell_ticks=settings.sell_ticks,
        )
    except (OSError, json.JSONDecodeError):
        return PriceSettings()


def save_rows(rows: list[OrderRow], path: Path = STATE_PATH, price_settings: PriceSettings | None = None) -> None:
    payload = {"version": 2, "rows": [asdict(row) for row in rows]}
    if price_settings is not None:
        payload["price_settings"] = asdict(price_settings)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


class LoginDialog(tk.Toplevel):
    def __init__(self, app: "DirectOrderBoardApp") -> None:
        super().__init__(app)
        self.app = app
        self.title("登入富邦 Neo")
        self.resizable(False, False)
        self.grab_set()
        saved = load_login_profile()
        self.environment_var = tk.StringVar(value="測試環境" if saved and saved.environment == "test" else "正式環境")
        self.user_id_var = tk.StringVar(value=saved.user_id if saved else "")
        self.password_var = tk.StringVar(value=saved.password if saved else "")
        self.cert_path_var = tk.StringVar(value=saved.cert_path if saved else "")
        self.cert_password_var = tk.StringVar(value=saved.cert_password if saved else "")
        self.remember_var = tk.BooleanVar(value=True)
        self.status_var = tk.StringVar(value="輸入資料後登入；登入資訊不會儲存。")
        self._build_layout()
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.after_idle(self._focus_user_id)

    def _build_layout(self) -> None:
        root = ttk.Frame(self, padding=22)
        root.pack(fill=tk.BOTH, expand=True)
        ttk.Label(root, text="富邦 Neo 登入", style="Title.TLabel").grid(row=0, column=0, columnspan=3, sticky=tk.W)
        ttk.Label(root, text="登入成功後才會開啟快速委託面板。", foreground="#8a3b00").grid(row=1, column=0, columnspan=3, sticky=tk.W, pady=(3, 16))
        fields = (
            ("交易環境", self.environment_var, ("正式環境", "測試環境"), None),
            ("身分證字號／帳號", self.user_id_var, None, None),
            ("登入密碼", self.password_var, None, "*"),
            ("憑證檔案", self.cert_path_var, None, None),
            ("憑證密碼", self.cert_password_var, None, "*"),
        )
        for row, (label, variable, choices, mask) in enumerate(fields, start=2):
            ttk.Label(root, text=label).grid(row=row, column=0, sticky=tk.W, padx=(0, 12), pady=5)
            if choices:
                widget = ttk.Combobox(root, textvariable=variable, values=choices, state="readonly", width=31)
                widget.current(0)
            else:
                widget = ttk.Entry(root, textvariable=variable, width=34, show=mask or "")
            widget.grid(row=row, column=1, sticky=tk.EW, pady=5)
            if label == "憑證檔案":
                ttk.Button(root, text="選擇檔案", command=self._browse_certificate).grid(row=row, column=2, padx=(8, 0), pady=5)
        ttk.Checkbutton(root, text="記住登入帳號、密碼與憑證資料（僅此 Windows 使用者可解密）", variable=self.remember_var).grid(row=7, column=0, columnspan=3, sticky=tk.W, pady=(10, 0))
        self.login_button = ttk.Button(root, text="登入", style="Add.TButton", command=self._submit)
        self.login_button.grid(row=8, column=1, sticky=tk.E, pady=(10, 4))
        ttk.Label(root, textvariable=self.status_var, foreground="#8a3b00").grid(row=9, column=0, columnspan=3, sticky=tk.W, pady=(4, 0))
        root.columnconfigure(1, weight=1)

    def _focus_user_id(self) -> None:
        for widget in self.winfo_children():
            if isinstance(widget, ttk.Frame):
                children = widget.grid_slaves(row=3, column=1)
                if children:
                    children[0].focus_set()
                return

    def _browse_certificate(self) -> None:
        selected = filedialog.askopenfilename(
            parent=self,
            title="選擇憑證檔案",
            filetypes=(("憑證檔案", "*.pfx *.p12"), ("所有檔案", "*.*")),
        )
        if selected:
            self.cert_path_var.set(selected)

    def _submit(self) -> None:
        try:
            login = LoginInput(
                user_id=self.user_id_var.get().strip(),
                password=self.password_var.get(),
                cert_path=self.cert_path_var.get().strip(),
                cert_password=self.cert_password_var.get(),
                environment=self.environment_var.get(),
            )
            environment = "test" if login.environment == "測試環境" else "prod"
            login = LoginInput(**{**asdict(login), "environment": environment})
            validate_login_input(login)
        except ValueError as exc:
            messagebox.showerror("登入資料錯誤", str(exc), parent=self)
            return
        try:
            if self.remember_var.get():
                save_login_profile(login)
            else:
                clear_login_profile()
        except OSError as exc:
            messagebox.showerror("無法儲存登入資料", str(exc), parent=self)
            return
        self.set_busy(True, "登入中…")
        self.app.login_from_dialog(login, self)

    def set_busy(self, busy: bool, message: str = "") -> None:
        self.login_button.configure(state=tk.DISABLED if busy else tk.NORMAL)
        if message:
            self.status_var.set(message)

    def login_failed(self, error: Exception) -> None:
        self.set_busy(False, "登入失敗，請檢查資料後再試。")
        messagebox.showerror("登入失敗", str(error), parent=self)

    def _cancel(self) -> None:
        self.grab_release()
        self.destroy()
        self.app.destroy()


class DirectOrderBoardApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("富邦 Neo 快速委託面板")
        self.geometry("940x720")
        self.minsize(820, 580)

        self.sdk: Any = None
        self.login_dialog: LoginDialog | None = None
        self.accounts: dict[str, Any] = {}
        self.order_lock = threading.Lock()
        self.row_widgets: list[dict[str, Any]] = []
        self.account_var = tk.StringVar()
        self.new_symbol_var = tk.StringVar()
        self.new_lots_var = tk.StringVar(value="1")
        saved_prices = load_price_settings()
        self.buy_price_mode_var = tk.StringVar(value=BUY_PRICE_MODES[saved_prices.buy_mode])
        self.buy_ticks_var = tk.StringVar(value=saved_prices.buy_ticks)
        self.sell_price_mode_var = tk.StringVar(value=SELL_PRICE_MODES[saved_prices.sell_mode])
        self.sell_ticks_var = tk.StringVar(value=saved_prices.sell_ticks)
        self.status_var = tk.StringVar(value="請先登入。")

        self._configure_style()
        self._build_layout()
        for row in load_rows():
            self._add_row(row)
        self.withdraw()
        self.show_login_dialog()

    def _configure_style(self) -> None:
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure(".", font=("Microsoft JhengHei UI", 10))
        style.configure("Title.TLabel", font=("Microsoft JhengHei UI", 18, "bold"))
        style.configure("Row.TLabel", background="#aaaaaa", foreground="white", relief="raised", padding=(14, 6), anchor=tk.CENTER)
        style.configure("Add.TButton", foreground="#ffffff", background="#ef7c28", font=("Microsoft JhengHei UI", 12, "bold"))
        style.configure("Buy.TButton", foreground="#0b7b50", background="#e7e3dc", font=("Microsoft JhengHei UI", 11, "bold"))
        style.configure("Sell.TButton", foreground="#c62828", background="#e7e3dc", font=("Microsoft JhengHei UI", 11, "bold"))
        style.configure("PriceNeutral.TCombobox", foreground="#1f1f1f")
        style.configure("PriceUp.TCombobox", foreground="#c62828")
        style.configure("PriceDown.TCombobox", foreground="#16803c")

    def _build_layout(self) -> None:
        root = ttk.Frame(self, padding=16)
        root.pack(fill=tk.BOTH, expand=True)
        ttk.Label(root, text="快速委託面板", style="Title.TLabel").pack(anchor=tk.W)
        ttk.Label(
            root,
            text="每列預先填入代號與張數（1 張 = 1,000 股）；買入用委賣一、賣出用委買一，直接送出整張限價委託。",
            foreground="#9b1c1c",
        ).pack(anchor=tk.W, pady=(4, 12))

        session = ttk.Frame(root)
        session.pack(fill=tk.X)
        ttk.Label(session, text="證券帳戶").pack(side=tk.LEFT)
        self.account_combo = ttk.Combobox(session, textvariable=self.account_var, state="disabled", width=28)
        self.account_combo.pack(side=tk.LEFT, padx=(8, 14))
        ttk.Button(session, text="重新登入", command=self.show_login_dialog).pack(side=tk.LEFT)

        table = ttk.LabelFrame(root, text="委託設定（列數不限）", padding=8)
        table.pack(fill=tk.BOTH, expand=True, pady=(12, 0))
        entry_area = ttk.Frame(table)
        entry_area.pack(fill=tk.X, pady=(0, 8))
        ttk.Label(entry_area, text="股票代號").grid(row=0, column=0, sticky=tk.W, padx=(4, 8))
        symbol_entry = ttk.Entry(entry_area, textvariable=self.new_symbol_var, width=16)
        symbol_entry.grid(row=0, column=1, sticky=tk.W, padx=(0, 16))
        ttk.Label(entry_area, text="張數").grid(row=0, column=2, sticky=tk.W, padx=(0, 8))
        lots_entry = ttk.Entry(entry_area, textvariable=self.new_lots_var, width=10)
        lots_entry.grid(row=0, column=3, sticky=tk.W, padx=(0, 16))
        ttk.Button(entry_area, text="新增", style="Add.TButton", command=self.add_configured_row).grid(row=0, column=4, sticky=tk.W)
        symbol_entry.bind("<Return>", lambda _event: self.add_configured_row())
        lots_entry.bind("<Return>", lambda _event: self.add_configured_row())

        pricing = ttk.LabelFrame(table, text="委託價格設定", padding=8)
        pricing.pack(fill=tk.X, pady=(0, 8))
        ttk.Label(pricing, text="買入").grid(row=0, column=0, sticky=tk.W, padx=(0, 8))
        self.buy_price_combo = ttk.Combobox(
            pricing, textvariable=self.buy_price_mode_var, state="readonly", width=18,
            values=tuple(BUY_PRICE_MODES.values()), style="PriceNeutral.TCombobox",
        )
        self.buy_price_combo.grid(row=0, column=1, sticky=tk.W)
        self.buy_price_combo.bind("<<ComboboxSelected>>", self._clear_price_combo_selection)
        ttk.Label(pricing, text="N 檔").grid(row=0, column=2, sticky=tk.W, padx=(16, 6))
        ttk.Entry(pricing, textvariable=self.buy_ticks_var, width=6).grid(row=0, column=3, sticky=tk.W)
        ttk.Label(pricing, text="賣出").grid(row=0, column=4, sticky=tk.W, padx=(26, 8))
        self.sell_price_combo = ttk.Combobox(
            pricing, textvariable=self.sell_price_mode_var, state="readonly", width=18,
            values=tuple(SELL_PRICE_MODES.values()), style="PriceNeutral.TCombobox",
        )
        self.sell_price_combo.grid(row=0, column=5, sticky=tk.W)
        self.sell_price_combo.bind("<<ComboboxSelected>>", self._clear_price_combo_selection)
        ttk.Label(pricing, text="N 檔").grid(row=0, column=6, sticky=tk.W, padx=(16, 6))
        ttk.Entry(pricing, textvariable=self.sell_ticks_var, width=6).grid(row=0, column=7, sticky=tk.W)
        ttk.Label(pricing, text="N 僅適用委賣一 + N 檔／委買一 - N 檔；此設定只會套用到之後新增的列。", foreground="#8a3b00").grid(row=1, column=0, columnspan=8, sticky=tk.W, pady=(5, 0))
        self.buy_price_mode_var.trace_add("write", self._refresh_price_mode_styles)
        self.sell_price_mode_var.trace_add("write", self._refresh_price_mode_styles)
        self._refresh_price_mode_styles()

        self.canvas = tk.Canvas(table, highlightthickness=0)
        scrollbar = ttk.Scrollbar(table, orient=tk.VERTICAL, command=self.canvas.yview)
        self.rows_frame = ttk.Frame(self.canvas)
        self.rows_frame.bind("<Configure>", lambda _event: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas_window = self.canvas.create_window((0, 0), window=self.rows_frame, anchor=tk.NW)
        self.canvas.configure(yscrollcommand=scrollbar.set)
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.canvas.bind("<Configure>", lambda event: self.canvas.itemconfigure(self.canvas_window, width=event.width))

        headers = ("#", "股票代號", "名稱", "張數", "", "", "")
        for column, label in enumerate(headers):
            ttk.Label(self.rows_frame, text=label).grid(row=0, column=column, sticky=tk.W, padx=4, pady=(0, 4))

        actions = ttk.Frame(root)
        actions.pack(fill=tk.X, pady=(10, 0))
        ttk.Button(actions, text="新增一列", command=lambda: self._add_row(OrderRow())).pack(side=tk.LEFT)
        ttk.Button(actions, text="儲存設定", command=self.save_state).pack(side=tk.LEFT, padx=(8, 0))
        ttk.Label(actions, textvariable=self.status_var).pack(side=tk.LEFT, padx=14)

        log_frame = ttk.LabelFrame(root, text="送單紀錄", padding=6)
        log_frame.pack(fill=tk.X, pady=(10, 0))
        self.log = scrolledtext.ScrolledText(log_frame, height=7, state=tk.DISABLED, font=("Consolas", 9))
        self.log.pack(fill=tk.BOTH, expand=True)
        self.protocol("WM_DELETE_WINDOW", self.close)

    def _refresh_price_mode_styles(self, *_args: Any) -> None:
        """Make the selected daily-limit price visually distinct."""
        if not hasattr(self, "buy_price_combo"):
            return
        buy_style = "PriceUp.TCombobox" if self.buy_price_mode_var.get() == "漲停價" else (
            "PriceDown.TCombobox" if self.buy_price_mode_var.get() == "跌停價" else "PriceNeutral.TCombobox"
        )
        sell_style = "PriceUp.TCombobox" if self.sell_price_mode_var.get() == "漲停價" else (
            "PriceDown.TCombobox" if self.sell_price_mode_var.get() == "跌停價" else "PriceNeutral.TCombobox"
        )
        self.buy_price_combo.configure(style=buy_style)
        self.sell_price_combo.configure(style=sell_style)

    @staticmethod
    def _clear_price_combo_selection(event: tk.Event) -> None:
        """Remove the blue text-selection highlight after choosing a price mode."""
        event.widget.selection_clear()

    def _add_row(self, row_data: OrderRow) -> None:
        row_number = len(self.row_widgets) + 1
        ttk.Label(self.rows_frame, text=str(row_number), width=3).grid(row=row_number, column=0, padx=4, pady=3, sticky=tk.W)
        ttk.Label(self.rows_frame, text=row_data.symbol or "--", style="Row.TLabel", width=14).grid(row=row_number, column=1, padx=4, pady=3, sticky=tk.EW)
        name_label = ttk.Label(self.rows_frame, text=row_data.name or "--", style="Row.TLabel", width=16)
        name_label.grid(row=row_number, column=2, padx=4, pady=3, sticky=tk.EW)
        ttk.Label(self.rows_frame, text=row_data.lots, style="Row.TLabel", width=9).grid(row=row_number, column=3, padx=4, pady=3, sticky=tk.EW)
        widgets = {"data": row_data, "name_label": name_label}
        buy_button = ttk.Button(self.rows_frame, text="買入", style="Buy.TButton", command=lambda: self.place_order(widgets, "buy"))
        sell_button = ttk.Button(self.rows_frame, text="賣出", style="Sell.TButton", command=lambda: self.place_order(widgets, "sell"))
        buy_button.grid(row=row_number, column=4, padx=(8, 2), pady=3)
        sell_button.grid(row=row_number, column=5, padx=2, pady=3)
        ttk.Button(self.rows_frame, text="刪除", command=lambda: self._delete_row(widgets)).grid(row=row_number, column=6, padx=(8, 2), pady=3)
        widgets["buy_button"] = buy_button
        widgets["sell_button"] = sell_button
        self.row_widgets.append(widgets)

    def add_configured_row(self) -> None:
        try:
            price_settings = self._current_price_settings()
            row_data = OrderRow(
                symbol=parse_symbol(self.new_symbol_var.get()), lots=str(parse_lots(self.new_lots_var.get()) // 1000),
                buy_mode=price_settings.buy_mode, buy_ticks=price_settings.buy_ticks,
                sell_mode=price_settings.sell_mode, sell_ticks=price_settings.sell_ticks,
            )
        except ValueError as exc:
            messagebox.showerror("設定錯誤", str(exc))
            return
        self._add_row(row_data)
        self.new_symbol_var.set("")
        self.new_lots_var.set("1")
        self.save_state()
        self._lookup_name(self.row_widgets[-1])

    def _delete_row(self, widgets: dict[str, Any]) -> None:
        # Recreate the editable rows to keep row numbers and button callbacks aligned.
        delete_index = self.row_widgets.index(widgets)
        remaining_rows = [row for index, row in enumerate(self._configured_rows()) if index != delete_index]
        for row in range(1, len(self.row_widgets) + 1):
            for widget in self.rows_frame.grid_slaves(row=row):
                widget.destroy()
        self.row_widgets.clear()
        for row_data in remaining_rows:
            self._add_row(row_data)
        self.save_state()

    def _configured_rows(self) -> list[OrderRow]:
        return [row["data"] for row in self.row_widgets]

    def _current_price_settings(self) -> PriceSettings:
        buy_modes = {label: key for key, label in BUY_PRICE_MODES.items()}
        sell_modes = {label: key for key, label in SELL_PRICE_MODES.items()}
        settings = PriceSettings(
            buy_mode=buy_modes.get(self.buy_price_mode_var.get(), "ask_n"),
            buy_ticks=self.buy_ticks_var.get().strip(),
            sell_mode=sell_modes.get(self.sell_price_mode_var.get(), "bid_n"),
            sell_ticks=self.sell_ticks_var.get().strip(),
        )
        parse_tick_count(settings.buy_ticks)
        parse_tick_count(settings.sell_ticks)
        return settings

    def save_state(self) -> None:
        try:
            save_rows(self._configured_rows(), price_settings=self._current_price_settings())
            self.status_var.set("設定已儲存。")
        except (OSError, ValueError) as exc:
            messagebox.showerror("儲存失敗", str(exc))

    def show_login_dialog(self) -> None:
        if self.login_dialog is not None and self.login_dialog.winfo_exists():
            self.login_dialog.deiconify()
            self.login_dialog.lift()
            self.login_dialog.focus_force()
            return
        if self.sdk is not None:
            try:
                self.sdk.logout()
            except Exception:
                pass
            self.sdk = None
            self.accounts.clear()
            self.account_combo.configure(values=(), state=tk.DISABLED)
            self.account_var.set("")
        self.withdraw()
        self.login_dialog = LoginDialog(self)
        self.login_dialog.deiconify()
        self.login_dialog.lift()
        self.login_dialog.focus_force()

    def login_from_dialog(self, login: LoginInput, dialog: LoginDialog) -> None:
        threading.Thread(target=self._login_worker, args=(login, dialog), daemon=True).start()

    def _login_worker(self, login: LoginInput, dialog: LoginDialog) -> None:
        sdk: Any = None
        try:
            sdk = make_login_sdk(login)
            result = sdk.login(login.user_id, login.password, login.cert_path, login.cert_password)
            if not bool(object_field(result, "is_success")):
                raise RuntimeError(object_field(result, "message") or "登入失敗。")
            accounts = stock_accounts(result)
            if not accounts:
                raise RuntimeError("此登入沒有可用的證券帳戶。")
            sdk.init_realtime(Mode.Normal)
            self.after(0, self._login_succeeded, sdk, accounts, dialog)
        except Exception as exc:
            if sdk is not None:
                try:
                    sdk.logout()
                except Exception:
                    pass
            self.after(0, self._login_failed, dialog, exc)

    def _login_succeeded(self, sdk: Any, accounts: list[Any], dialog: LoginDialog) -> None:
        self.sdk = sdk
        self.accounts = {account_label(account): account for account in accounts}
        labels = list(self.accounts)
        self.account_combo.configure(values=labels, state="readonly")
        self.account_var.set(labels[0])
        self.status_var.set("登入完成；買入取委賣一，賣出取委買一。")
        dialog.grab_release()
        dialog.destroy()
        self.login_dialog = None
        self.deiconify()
        for row in self.row_widgets:
            if not row["data"].name:
                self._lookup_name(row)

    def _login_failed(self, dialog: LoginDialog, exc: Exception) -> None:
        if dialog.winfo_exists():
            dialog.login_failed(exc)

    def _lookup_name(self, row: dict[str, Any]) -> None:
        if self.sdk is None:
            return
        symbol = row["data"].symbol
        if not symbol:
            return
        threading.Thread(target=self._lookup_name_worker, args=(row, symbol), daemon=True).start()

    def _lookup_name_worker(self, row: dict[str, Any], symbol: str) -> None:
        try:
            response = self.sdk.marketdata.rest_client.stock.intraday.quote(symbol=symbol)
            name = stock_name(response)
        except Exception:
            name = "--"
        self.after(0, self._name_lookup_done, row, name)

    def _name_lookup_done(self, row: dict[str, Any], name: str) -> None:
        if row not in self.row_widgets:
            return
        data = row["data"]
        row["data"] = OrderRow(
            symbol=data.symbol, name=name if name != "--" else data.name, lots=data.lots,
            buy_mode=data.buy_mode, buy_ticks=data.buy_ticks, sell_mode=data.sell_mode, sell_ticks=data.sell_ticks,
        )
        row["name_label"].configure(text=row["data"].name or "--")
        self.save_state()

    def place_order(self, row: dict[str, Any], side: str) -> None:
        account = self.accounts.get(self.account_var.get())
        if self.sdk is None or account is None:
            messagebox.showerror("尚未登入", "請先登入並選擇證券帳戶。")
            return
        try:
            symbol = parse_symbol(row["data"].symbol)
            quantity = parse_lots(row["data"].lots)
            data = row["data"]
            price_settings = PriceSettings(data.buy_mode, data.buy_ticks, data.sell_mode, data.sell_ticks)
            parse_tick_count(price_settings.buy_ticks)
            parse_tick_count(price_settings.sell_ticks)
        except ValueError as exc:
            messagebox.showerror("委託設定錯誤", str(exc))
            return
        try:
            save_rows(self._configured_rows(), price_settings=price_settings)
        except OSError as exc:
            messagebox.showerror("儲存失敗", str(exc))
            return
        row["buy_button"].configure(state=tk.DISABLED)
        row["sell_button"].configure(state=tk.DISABLED)
        source = "委賣一" if side == "buy" else "委買一"
        self.status_var.set(f"讀取 {symbol} {source} 並送出{'買入' if side == 'buy' else '賣出'}委託中…")
        threading.Thread(target=self._place_order_worker, args=(row, account, symbol, quantity, side, price_settings), daemon=True).start()

    def _place_order_worker(
        self, row: dict[str, Any], account: Any, symbol: str, quantity: int, side: str, price_settings: PriceSettings,
    ) -> None:
        try:
            quote_result = self.sdk.stock.query_symbol_quote(account, symbol)
            if object_field(quote_result, "is_success") is False:
                raise ValueError(object_field(quote_result, "message") or "找不到可委託的股票代號。")
            active_mode = price_settings.buy_mode if side == "buy" else price_settings.sell_mode
            quote_snapshot = None if active_mode == "market" else self.sdk.marketdata.rest_client.stock.intraday.quote(symbol=symbol)
            price_type, price, price_rule = selected_order_price(side, price_settings, quote_snapshot, quote_result)
            order = Order(
                buy_sell=BSAction.Buy if side == "buy" else BSAction.Sell,
                symbol=symbol,
                quantity=quantity,
                market_type=MarketType.Common,
                price_type=price_type,
                time_in_force=TimeInForce.ROD,
                order_type=OrderType.Stock,
                price=price,
            )
            with self.order_lock:
                result = self.sdk.stock.place_order(account, order)
            success = bool(object_field(result, "is_success"))
            detail = object_field(result, "message") or ""
            result_data = object_field(result, "data") or result
            order_no = object_field(result_data, "order_no", "seq_no") or "--"
            self.after(0, self._order_finished, row, success, symbol, quantity, price or "市價", side, f"{price_rule} | {order_no} {detail}".strip())
        except Exception as exc:
            self.after(0, self._order_finished, row, False, symbol, quantity, "--", side, f"{type(exc).__name__}: {exc}")

    def _order_finished(self, row: dict[str, Any], success: bool, symbol: str, quantity: int, price: str, side: str, detail: str) -> None:
        row["buy_button"].configure(state=tk.NORMAL)
        row["sell_button"].configure(state=tk.NORMAL)
        action = "買入" if side == "buy" else "賣出"
        status = "送單成功" if success else "送單失敗"
        self.status_var.set(f"{symbol} {action}：{status}")
        timestamp = datetime.now(TAIPEI_TZ).strftime("%H:%M:%S")
        self.log.configure(state=tk.NORMAL)
        source = "委賣一" if side == "buy" else "委買一"
        self.log.insert(tk.END, f"[{timestamp}] {status} | {symbol} | {action} | {quantity:,} 股 | {source} {price} | {detail}\n")
        self.log.see(tk.END)
        self.log.configure(state=tk.DISABLED)

    def close(self) -> None:
        self.save_state()
        sdk, self.sdk = self.sdk, None
        try:
            if sdk is not None:
                sdk.logout()
        finally:
            self.destroy()


if __name__ == "__main__":
    DirectOrderBoardApp().mainloop()
