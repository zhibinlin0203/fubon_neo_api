import importlib.util
from pathlib import Path
import sys
import tempfile
import types
import unittest


tk = types.ModuleType("tkinter")
tk.Tk = type("Tk", (), {})
tk.Toplevel = type("Toplevel", (), {})
tk.BOTH = tk.X = tk.W = tk.LEFT = tk.RIGHT = tk.Y = tk.VERTICAL = tk.END = tk.NORMAL = tk.DISABLED = ""
ttk = types.ModuleType("tkinter.ttk")
for name in ("Style", "Frame", "Label", "LabelFrame", "Combobox", "Button", "Scrollbar", "Entry"):
    setattr(ttk, name, type(name, (), {}))
messagebox = types.ModuleType("tkinter.messagebox")
filedialog = types.ModuleType("tkinter.filedialog")
scrolledtext = types.ModuleType("tkinter.scrolledtext")
scrolledtext.ScrolledText = type("ScrolledText", (), {})
tk.ttk = ttk
tk.messagebox = messagebox
tk.filedialog = filedialog
tk.scrolledtext = scrolledtext
sys.modules["tkinter"] = tk
sys.modules["tkinter.ttk"] = ttk
sys.modules["tkinter.messagebox"] = messagebox
sys.modules["tkinter.filedialog"] = filedialog
sys.modules["tkinter.scrolledtext"] = scrolledtext

fubon_neo = types.ModuleType("fubon_neo")
sdk = types.ModuleType("fubon_neo.sdk")
sdk.Mode = types.SimpleNamespace(Normal="normal")
sdk.FubonSDK = type("FubonSDK", (), {})
sdk.Order = type("Order", (), {})
constant = types.ModuleType("fubon_neo.constant")
constant.BSAction = types.SimpleNamespace(Buy="buy", Sell="sell")
constant.MarketType = types.SimpleNamespace(Common="common")
constant.OrderType = types.SimpleNamespace(Stock="stock")
constant.PriceType = types.SimpleNamespace(Limit="limit", Market="market")
constant.TimeInForce = types.SimpleNamespace(ROD="rod")
sys.modules["fubon_neo"] = fubon_neo
sys.modules["fubon_neo.sdk"] = sdk
sys.modules["fubon_neo.constant"] = constant

MODULE_PATH = Path(__file__).with_name("direct_order_board_gui.py")
SPEC = importlib.util.spec_from_file_location("direct_order_board_gui", MODULE_PATH)
assert SPEC and SPEC.loader
app = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = app
SPEC.loader.exec_module(app)


class DirectOrderBoardTests(unittest.TestCase):
    def test_parses_symbol_lots_and_price(self) -> None:
        self.assertEqual(app.parse_symbol(" 00631l "), "00631L")
        self.assertEqual(app.parse_lots("3"), 3000)

    def test_rejects_invalid_values(self) -> None:
        with self.assertRaises(ValueError):
            app.parse_symbol("2330-1")
        with self.assertRaises(ValueError):
            app.parse_lots("0")

    def test_uses_ask_one_for_buy_and_bid_one_for_sell(self) -> None:
        quote = {"data": {"bids": [["33.20", 100]], "asks": [{"price": "33.25", "size": 90}]}}
        self.assertEqual(app.best_quote_price(quote, "bid"), "33.2")
        self.assertEqual(app.best_quote_price(quote, "ask"), "33.25")

    def test_reads_stock_name_from_quote(self) -> None:
        self.assertEqual(app.stock_name({"data": {"name": "台積電"}}), "台積電")
        self.assertEqual(app.stock_name({"data": {"info": {"shortName": "元大台灣50"}}}), "元大台灣50")

    def test_rows_persist_without_a_row_limit(self) -> None:
        expected = [app.OrderRow(symbol=f"{2300 + index}", lots=str(index + 1)) for index in range(50)]
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "state.json"
            app.save_rows(expected, path)
            self.assertEqual(app.load_rows(path), expected)

    def test_missing_state_starts_with_an_empty_list(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            self.assertEqual(app.load_rows(Path(temporary_directory) / "missing.json"), [])

    def test_login_input_requires_all_fields_and_an_existing_certificate(self) -> None:
        with tempfile.TemporaryDirectory() as temporary_directory:
            certificate = Path(temporary_directory) / "user.pfx"
            certificate.write_bytes(b"test")
            app.validate_login_input(app.LoginInput("A123456789", "password", str(certificate), "cert-password", "test"))
            with self.assertRaises(ValueError):
                app.validate_login_input(app.LoginInput("", "password", str(certificate), "cert-password", "test"))

    def test_price_settings_choose_opposite_best_price_with_ticks_and_limits(self) -> None:
        market = {"data": {"bids": [["33.20", 100]], "asks": [["33.25", 90]], "securityType": "STOCK"}}
        broker = {"data": {"limit_down_price": "30", "limit_up_price": "35"}}
        price_type, price, _ = app.selected_order_price("buy", app.PriceSettings(buy_ticks="2"), market, broker)
        self.assertEqual((price_type, price), ("limit", "33.35"))
        price_type, price, _ = app.selected_order_price("sell", app.PriceSettings(sell_ticks="2"), market, broker)
        self.assertEqual((price_type, price), ("limit", "33.1"))
        price_type, price, _ = app.selected_order_price("buy", app.PriceSettings(buy_mode="limit_up"), market, broker)
        self.assertEqual((price_type, price), ("limit", "35"))
        price_type, price, _ = app.selected_order_price("sell", app.PriceSettings(sell_mode="market"), None, broker)
        self.assertEqual((price_type, price), ("market", None))

    def test_price_settings_persist(self) -> None:
        settings = app.PriceSettings("limit_up", "4", "limit_down", "3")
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "state.json"
            app.save_rows([app.OrderRow("2330", "台積電", "2")], path, settings)
            self.assertEqual(app.load_price_settings(path), settings)

    def test_each_row_keeps_its_own_price_rule(self) -> None:
        first = app.OrderRow("2330", "台積電", "1", "ask_n", "0", "bid_n", "0")
        later = app.OrderRow("2330", "台積電", "1", "market", "0", "market", "0")
        with tempfile.TemporaryDirectory() as temporary_directory:
            path = Path(temporary_directory) / "state.json"
            app.save_rows([first, later], path, app.PriceSettings("market", "0", "market", "0"))
            loaded = app.load_rows(path)
            self.assertEqual(loaded[0].buy_mode, "ask_n")
            self.assertEqual(loaded[0].sell_mode, "bid_n")
            self.assertEqual(loaded[1].buy_mode, "market")
            self.assertEqual(loaded[1].sell_mode, "market")

if __name__ == "__main__":
    unittest.main()
