Option Explicit

Dim shell, fileSystem, scriptFolder, pythonExe, scriptFile, command
Set shell = CreateObject("WScript.Shell")
Set fileSystem = CreateObject("Scripting.FileSystemObject")

scriptFolder = fileSystem.GetParentFolderName(WScript.ScriptFullName)
pythonExe = "C:\Users\zhibi\AppData\Local\Programs\Python\Python312\python.exe"
scriptFile = scriptFolder & "\direct_order_board_gui.py"

If Not fileSystem.FileExists(pythonExe) Then
    MsgBox "找不到 Python 3.12：" & vbCrLf & pythonExe, vbCritical, "無法啟動快速委託面板"
    WScript.Quit 1
End If

command = Chr(34) & pythonExe & Chr(34) & " " & Chr(34) & scriptFile & Chr(34)
shell.Run command, 1, False
