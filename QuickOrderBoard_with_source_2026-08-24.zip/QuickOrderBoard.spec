# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['direct_order_board_gui.py'],
    pathex=[],
    binaries=[('C:\\Users\\zhibi\\AppData\\Local\\Programs\\Python\\Python312\\DLLs\\_tkinter.pyd', '.'), ('C:\\Users\\zhibi\\AppData\\Local\\Programs\\Python\\Python312\\DLLs\\tcl86t.dll', '.'), ('C:\\Users\\zhibi\\AppData\\Local\\Programs\\Python\\Python312\\DLLs\\tk86t.dll', '.')],
    datas=[('D:\\工作資料\\Py\\fubon_neo_test_web\\direct_order_board_gui\\runtime_tcl\\tcl8.6', '_tcl_data'), ('D:\\工作資料\\Py\\fubon_neo_test_web\\direct_order_board_gui\\runtime_tcl\\tk8.6', '_tk_data')],
    hiddenimports=['tkinter', 'tkinter.ttk', 'tkinter.filedialog', 'tkinter.scrolledtext', '_tkinter'],
    hookspath=['.\\packaging_hooks'],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='QuickOrderBoard',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='QuickOrderBoard',
)
