@echo off
chcp 65001 >nul
setlocal
set "PYTHON_EXE=C:\Users\zhibi\AppData\Local\Programs\Python\Python312\python.exe"

if not exist "%PYTHON_EXE%" (
    echo 找不到已設定的 Python 3.12：
    echo %PYTHON_EXE%
    echo.
    echo 請改用 release\QuickOrderBoard\QuickOrderBoard.exe，或安裝 Python 3.12 與富邦 Neo SDK。
    pause
    exit /b 1
)

"%PYTHON_EXE%" "%~dp0direct_order_board_gui.py"
if errorlevel 1 pause
